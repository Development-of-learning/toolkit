# @actions/exec Releases

### 1.1.1
- Update `lockfileVersion` to `v2` in `package-lock.json [#1024](https://github.com/actions/toolkit/pull/1024) 

### 1.1.0

- [Fix stdline dropping large output](https://github.com/actions/toolkit/pull/773)
- [Add getExecOutput function](https://github.com/actions/toolkit/pull/814)
- [Better error for bad cwd](https://github.com/actions/toolkit/pull/793)

### 1.0.3

- [Add \"types\" to package.json](https://github.com/actions/toolkit/pull/221)

### 1.0.2

- [Which before invoking tool](https://github.com/actions/toolkit/pull/220)

### 1.0.0

- Initial release