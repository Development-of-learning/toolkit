#!/usr/bin/env bash

read var
echo $var
